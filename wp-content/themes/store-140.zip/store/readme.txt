Dynamo is a Premium WordPress theme by Obox
http://www.obox-design.com

For help and theme documentation, visit the Obox Knowledgebase:
http://kb.oboxsites.com/

For Update Notes, subscribe to updates here:
http://kb.oboxsites.com/category/hotfixes/

For support, visit our forums:
http://www.oboxthemes.com/support