<li class="post">
	<h2 class="post-title"><a href="#"><?php _e("No Content Found", "ocmx"); ?></a></h2>
	<div class="copy <?php echo $image_class; ?>">
		<?php _e("The content you are looking for does not exist", "ocmx"); ?>
	</div>
</li>
